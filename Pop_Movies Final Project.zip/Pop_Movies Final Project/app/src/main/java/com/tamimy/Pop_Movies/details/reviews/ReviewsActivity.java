package com.tamimy.Pop_Movies.details.reviews;

import android.support.v4.app.Fragment;

import com.tamimy.Pop_Movies.BaseActivity;

/**
 * Created by mody sherif on 12/25/15.
 */
public class ReviewsActivity extends BaseActivity {
    @Override
    protected Fragment createFragment() {
        return  ReviewsFragment.newInstance(getIntent().getIntExtra("extra_movie_id",0));
    }
}
