package com.tamimy.Pop_Movies.network;

/**
 * Created by mody sherif on 12/25/15.
 */

public class UnauthorizedException extends Exception {
}
