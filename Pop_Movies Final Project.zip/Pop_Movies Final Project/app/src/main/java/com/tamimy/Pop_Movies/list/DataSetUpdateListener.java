package com.tamimy.Pop_Movies.list;

import com.tamimy.Pop_Movies.Movie;

import java.util.List;



public interface DataSetUpdateListener {
    public void onDataSetUpdated(List<Movie> movies);
}
