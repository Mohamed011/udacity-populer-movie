package com.tamimy.Pop_Movies.details.reviews;

import java.util.Map;


public interface ReviewsDataSetUpdateListener {
    void onDataSetUpdated(Map<String, String> trailers);
}
