package com.tamimy.Pop_Movies.details.trailers;

import java.util.Map;


public interface TrailersDataSetUpdateListener {
    void onDataSetUpdated(Map<String, String> trailers);
}
